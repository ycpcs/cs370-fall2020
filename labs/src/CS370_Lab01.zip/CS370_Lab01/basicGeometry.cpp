#include "stdio.h"
#include "vgl.h"
#include "utils.h"

enum VAO_IDs {Triangles, NumVAOs};
enum Buffer_IDs {PosBuffer, NumBuffers};

GLuint VAOs[NumVAOs];
GLuint Buffers[NumBuffers];

GLint numVertices = 6;
GLint posCoords = 2;

// Shader variables
GLuint program;
GLuint vPos;
const char *vertex_shader = "../basic.vert";
const char *frag_shader = "../basic.frag";

void build_geometry( );
void display( );
void render_scene( );

int main(int argc, char**argv)
{
	// Create OpenGL window
	GLFWwindow* window = CreateWindow("Basic Geometry");
    if (!window) {
        fprintf(stderr, "ERROR: could not open window with GLFW3\n");
        glfwTerminate();
        return 1;
    } else {
        printf("OpenGL window successfully created\n");
    }

	// Create geometry buffers
    build_geometry();
    
    // Load shaders
	ShaderInfo shaders[] = { {GL_VERTEX_SHADER, vertex_shader},{GL_FRAGMENT_SHADER, frag_shader},{GL_NONE, NULL} };
	program = LoadShaders(shaders);

	// Select shader program and associate shader variables
	glUseProgram(program);
	glBindBuffer(GL_ARRAY_BUFFER, Buffers[PosBuffer]);
	vPos = glGetAttribLocation(program, "vPosition");
	glVertexAttribPointer(vPos, posCoords, GL_FLOAT, GL_FALSE, 0, NULL);
	glEnableVertexAttribArray(vPos);

    // Start loop
    while ( !glfwWindowShouldClose( window ) ) {
        // Draw graphics
        display();
        // Update other events like input handling
        glfwPollEvents();
        // Swap buffer onto screen
        glfwSwapBuffers( window );
    }

    // Close window
    glfwTerminate();
    return 0;
}

void build_geometry( )
{
	// TODO: Generate and bind vertex arrays

	// TODO: Define vertices (ensure proper orientation)
	
	// TODO: Generate and bind vertex buffers

	// TODO: Load vertex data into buffer

}

void display( )
{
	// TODO: Clear window

	// TODO: Render objects

	// TODO: Flush pipeline

}

void render_scene( ) {
	// TODO: Bind Triangles vertex array

	// TODO: Draw geometry

}

